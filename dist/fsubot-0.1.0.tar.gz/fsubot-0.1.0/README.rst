FSUBot
======

A bot which serves as the foundation for other bots for use on the
Florida State University website. It is useful for automating tasks that
are otherwise very menial and tedious.
